using System.Data.SQLite;

namespace WarqERP.Models;

public static class Database
{
    static string DbPath => Path.Combine("database", "erp_system.db");

    static SQLiteConnection Connect()
    {
        var connection = new SQLiteConnection($"Data Source={DbPath};Version=3;");
        connection.Open();

        using var command = new SQLiteCommand("PRAGMA foreign_keys = ON", connection);
        command.ExecuteNonQuery();

        return connection;
    }

    static void Add(SQLiteCommand command, string name, object value)
    {
        command.Parameters.AddWithValue(name, value);
    }

    static int Number(string sql)
    {
        using var connection = Connect();
        using var command = new SQLiteCommand(sql, connection);
        return Convert.ToInt32(command.ExecuteScalar() ?? 0);
    }

    public static Dashboard Dashboard()
    {
        return new Dashboard
        {
            Suppliers = Number("SELECT COUNT(*) FROM Supplier"),
            Products = Number("SELECT COUNT(*) FROM Product"),
            Orders = Number("SELECT COUNT(*) FROM PurchaseOrder"),
            LowStock = Number("SELECT COUNT(*) FROM Product WHERE StockQuantity < 20")
        };
    }

    public static List<Supplier> Suppliers()
    {
        var list = new List<Supplier>();
        using var connection = Connect();
        using var command = new SQLiteCommand("SELECT * FROM Supplier ORDER BY SupplierId DESC", connection);
        using var reader = command.ExecuteReader();

        while (reader.Read())
        {
            list.Add(new Supplier
            {
                SupplierId = Convert.ToInt32(reader["SupplierId"]),
                SupplierName = reader["SupplierName"].ToString() ?? "",
                ContactNumber = reader["ContactNumber"].ToString() ?? "",
                Email = reader["Email"].ToString() ?? "",
                Address = reader["Address"].ToString() ?? ""
            });
        }

        return list;
    }

    public static Supplier Supplier(int id)
    {
        return Suppliers().FirstOrDefault(x => x.SupplierId == id) ?? new Supplier();
    }

    public static void SaveSupplier(Supplier supplier)
    {
        using var connection = Connect();
        using var command = connection.CreateCommand();

        if (supplier.SupplierId == 0)
        {
            command.CommandText = @"
                INSERT INTO Supplier (SupplierName, ContactNumber, Email, Address)
                VALUES (@name, @phone, @email, @address)";
        }
        else
        {
            command.CommandText = @"
                UPDATE Supplier
                SET SupplierName = @name, ContactNumber = @phone, Email = @email, Address = @address
                WHERE SupplierId = @id";
            Add(command, "@id", supplier.SupplierId);
        }

        Add(command, "@name", supplier.SupplierName);
        Add(command, "@phone", supplier.ContactNumber);
        Add(command, "@email", supplier.Email);
        Add(command, "@address", supplier.Address);
        command.ExecuteNonQuery();
    }

    public static void DeleteSupplier(int id)
    {
        using var connection = Connect();
        using var command = new SQLiteCommand("DELETE FROM Supplier WHERE SupplierId = @id", connection);
        Add(command, "@id", id);
        command.ExecuteNonQuery();
    }

    public static List<Employee> Employees()
    {
        var list = new List<Employee>();
        using var connection = Connect();
        using var command = new SQLiteCommand("SELECT * FROM Employee ORDER BY EmployeeId DESC", connection);
        using var reader = command.ExecuteReader();

        while (reader.Read())
        {
            list.Add(new Employee
            {
                EmployeeId = Convert.ToInt32(reader["EmployeeId"]),
                FirstName = reader["FirstName"].ToString() ?? "",
                LastName = reader["LastName"].ToString() ?? "",
                Position = reader["Position"].ToString() ?? "",
                Email = reader["Email"].ToString() ?? "",
                Phone = reader["Phone"].ToString() ?? "",
                Salary = Convert.ToDecimal(reader["Salary"])
            });
        }

        return list;
    }

    public static Employee Employee(int id)
    {
        return Employees().FirstOrDefault(x => x.EmployeeId == id) ?? new Employee();
    }

    public static void SaveEmployee(Employee employee)
    {
        using var connection = Connect();
        using var command = connection.CreateCommand();

        if (employee.EmployeeId == 0)
        {
            command.CommandText = @"
                INSERT INTO Employee (FirstName, LastName, Position, Email, Phone, Salary)
                VALUES (@first, @last, @position, @email, @phone, @salary)";
        }
        else
        {
            command.CommandText = @"
                UPDATE Employee
                SET FirstName = @first, LastName = @last, Position = @position,
                    Email = @email, Phone = @phone, Salary = @salary
                WHERE EmployeeId = @id";
            Add(command, "@id", employee.EmployeeId);
        }

        Add(command, "@first", employee.FirstName);
        Add(command, "@last", employee.LastName);
        Add(command, "@position", employee.Position);
        Add(command, "@email", employee.Email);
        Add(command, "@phone", employee.Phone);
        Add(command, "@salary", employee.Salary);
        command.ExecuteNonQuery();
    }

    public static void DeleteEmployee(int id)
    {
        using var connection = Connect();
        using var command = new SQLiteCommand("DELETE FROM Employee WHERE EmployeeId = @id", connection);
        Add(command, "@id", id);
        command.ExecuteNonQuery();
    }

    public static List<string> Categories()
    {
        var list = new List<string>();
        using var connection = Connect();
        using var command = new SQLiteCommand("SELECT CategoryName FROM Category ORDER BY CategoryName", connection);
        using var reader = command.ExecuteReader();

        while (reader.Read())
        {
            list.Add(reader["CategoryName"].ToString() ?? "");
        }

        return list;
    }

    public static List<Product> Products()
    {
        var list = new List<Product>();
        using var connection = Connect();
        using var command = new SQLiteCommand(@"
            SELECT p.ProductId, p.ProductName, c.CategoryName, p.Price, p.StockQuantity
            FROM Product p
            JOIN Category c ON c.CategoryId = p.CategoryId
            ORDER BY p.ProductId DESC", connection);
        using var reader = command.ExecuteReader();

        while (reader.Read())
        {
            list.Add(new Product
            {
                ProductId = Convert.ToInt32(reader["ProductId"]),
                ProductName = reader["ProductName"].ToString() ?? "",
                CategoryName = reader["CategoryName"].ToString() ?? "",
                Price = Convert.ToDecimal(reader["Price"]),
                StockQuantity = Convert.ToInt32(reader["StockQuantity"])
            });
        }

        return list;
    }

    public static Product Product(int id)
    {
        return Products().FirstOrDefault(x => x.ProductId == id) ?? new Product();
    }

    public static void SaveProduct(Product product)
    {
        using var connection = Connect();
        using var command = connection.CreateCommand();

        if (product.ProductId == 0)
        {
            command.CommandText = @"
                INSERT INTO Product (ProductName, CategoryId, Price, StockQuantity)
                VALUES (@name, (SELECT CategoryId FROM Category WHERE CategoryName = @category), @price, @stock)";
        }
        else
        {
            command.CommandText = @"
                UPDATE Product
                SET ProductName = @name,
                    CategoryId = (SELECT CategoryId FROM Category WHERE CategoryName = @category),
                    Price = @price,
                    StockQuantity = @stock
                WHERE ProductId = @id";
            Add(command, "@id", product.ProductId);
        }

        Add(command, "@name", product.ProductName);
        Add(command, "@category", product.CategoryName);
        Add(command, "@price", product.Price);
        Add(command, "@stock", product.StockQuantity);
        command.ExecuteNonQuery();
    }

    public static void DeleteProduct(int id)
    {
        using var connection = Connect();
        using var command = new SQLiteCommand("DELETE FROM Product WHERE ProductId = @id", connection);
        Add(command, "@id", id);
        command.ExecuteNonQuery();
    }

    public static List<PurchaseOrder> Orders()
    {
        var list = new List<PurchaseOrder>();
        using var connection = Connect();
        using var command = new SQLiteCommand(@"
            SELECT o.PurchaseOrderId, o.OrderDate, s.SupplierName,
                   e.FirstName || ' ' || e.LastName AS EmployeeName,
                   p.ProductName, d.Quantity, o.TotalAmount, o.Status
            FROM PurchaseOrder o
            JOIN Supplier s ON s.SupplierId = o.SupplierId
            JOIN Employee e ON e.EmployeeId = o.EmployeeId
            JOIN PurchaseOrderDetails d ON d.PurchaseOrderId = o.PurchaseOrderId
            JOIN Product p ON p.ProductId = d.ProductId
            ORDER BY o.PurchaseOrderId DESC", connection);
        using var reader = command.ExecuteReader();

        while (reader.Read())
        {
            list.Add(new PurchaseOrder
            {
                PurchaseOrderId = Convert.ToInt32(reader["PurchaseOrderId"]),
                OrderDate = reader["OrderDate"].ToString() ?? "",
                SupplierName = reader["SupplierName"].ToString() ?? "",
                EmployeeName = reader["EmployeeName"].ToString() ?? "",
                ProductName = reader["ProductName"].ToString() ?? "",
                Quantity = Convert.ToInt32(reader["Quantity"]),
                TotalAmount = Convert.ToDecimal(reader["TotalAmount"]),
                Status = reader["Status"].ToString() ?? ""
            });
        }

        return list;
    }

    public static void SaveOrder(NewOrder order)
    {
        using var connection = Connect();
        using var transaction = connection.BeginTransaction();

        using var priceCommand = new SQLiteCommand("SELECT Price FROM Product WHERE ProductId = @id", connection, transaction);
        Add(priceCommand, "@id", order.ProductId);

        var price = Convert.ToDecimal(priceCommand.ExecuteScalar() ?? 0);
        var total = price * order.Quantity;

        using var orderCommand = new SQLiteCommand(@"
            INSERT INTO PurchaseOrder (OrderDate, SupplierId, EmployeeId, TotalAmount, Status)
            VALUES (@date, @supplier, @employee, @total, @status)", connection, transaction);

        Add(orderCommand, "@date", DateTime.Now.ToString("yyyy-MM-dd"));
        Add(orderCommand, "@supplier", order.SupplierId);
        Add(orderCommand, "@employee", order.EmployeeId);
        Add(orderCommand, "@total", total);
        Add(orderCommand, "@status", order.Status);
        orderCommand.ExecuteNonQuery();

        using var detailCommand = new SQLiteCommand(@"
            INSERT INTO PurchaseOrderDetails (PurchaseOrderId, ProductId, Quantity, UnitPrice)
            VALUES (last_insert_rowid(), @product, @quantity, @price)", connection, transaction);

        Add(detailCommand, "@product", order.ProductId);
        Add(detailCommand, "@quantity", order.Quantity);
        Add(detailCommand, "@price", price);
        detailCommand.ExecuteNonQuery();

        transaction.Commit();
    }

    public static void DeleteOrder(int id)
    {
        using var connection = Connect();
        using var command = new SQLiteCommand("DELETE FROM PurchaseOrder WHERE PurchaseOrderId = @id", connection);
        Add(command, "@id", id);
        command.ExecuteNonQuery();
    }
}

public class Dashboard
{
    public int Suppliers { get; set; }
    public int Products { get; set; }
    public int Orders { get; set; }
    public int LowStock { get; set; }
}

public class Supplier
{
    public int SupplierId { get; set; }
    public string SupplierName { get; set; } = "";
    public string ContactNumber { get; set; } = "";
    public string Email { get; set; } = "";
    public string Address { get; set; } = "";
}

public class Employee
{
    public int EmployeeId { get; set; }
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string Position { get; set; } = "";
    public string Email { get; set; } = "";
    public string Phone { get; set; } = "";
    public decimal Salary { get; set; }
}

public class Product
{
    public int ProductId { get; set; }
    public string ProductName { get; set; } = "";
    public string CategoryName { get; set; } = "";
    public decimal Price { get; set; }
    public int StockQuantity { get; set; }
}

public class PurchaseOrder
{
    public int PurchaseOrderId { get; set; }
    public string OrderDate { get; set; } = "";
    public string SupplierName { get; set; } = "";
    public string EmployeeName { get; set; } = "";
    public string ProductName { get; set; } = "";
    public int Quantity { get; set; }
    public decimal TotalAmount { get; set; }
    public string Status { get; set; } = "";
}

public class NewOrder
{
    public int SupplierId { get; set; }
    public int EmployeeId { get; set; }
    public int ProductId { get; set; }
    public int Quantity { get; set; } = 1;
    public string Status { get; set; } = "Pending";
}
