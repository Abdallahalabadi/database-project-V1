using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WarqERP.Models;

namespace WarqERP.Pages;

public class EmployeesModel : PageModel
{
    [BindProperty]
    public Employee Employee { get; set; } = new();

    public List<Employee> Employees { get; set; } = [];
    public string Message { get; set; } = "";

    public void OnGet(int? id)
    {
        if (id != null)
            Employee = Database.Employee(id.Value);

        Employees = Database.Employees();
        Message = TempData["Message"] as string ?? "";
    }

    public IActionResult OnPostSave()
    {
        Database.SaveEmployee(Employee);
        TempData["Message"] = "Saved successfully.";
        return RedirectToPage();
    }

    public IActionResult OnPostDelete(int id)
    {
        Database.DeleteEmployee(id);
        TempData["Message"] = "Deleted successfully.";
        return RedirectToPage();
    }
}
