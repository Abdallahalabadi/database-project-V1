using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WarqERP.Models;

namespace WarqERP.Pages;

public class ProductsModel : PageModel
{
    [BindProperty]
    public Product Product { get; set; } = new();

    public List<Product> Products { get; set; } = [];
    public List<string> Categories { get; set; } = [];
    public string Message { get; set; } = "";

    public void OnGet(int? id)
    {
        if (id != null)
            Product = Database.Product(id.Value);

        Products = Database.Products();
        Categories = Database.Categories();
        Message = TempData["Message"] as string ?? "";
    }

    public IActionResult OnPostSave()
    {
        Database.SaveProduct(Product);
        TempData["Message"] = "Saved successfully.";
        return RedirectToPage();
    }

    public IActionResult OnPostDelete(int id)
    {
        Database.DeleteProduct(id);
        TempData["Message"] = "Deleted successfully.";
        return RedirectToPage();
    }
}
