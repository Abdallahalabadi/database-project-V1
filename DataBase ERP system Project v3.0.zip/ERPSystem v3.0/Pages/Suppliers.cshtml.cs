using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WarqERP.Models;

namespace WarqERP.Pages;

public class SuppliersModel : PageModel
{
    [BindProperty]
    public Supplier Supplier { get; set; } = new();

    public List<Supplier> Suppliers { get; set; } = [];
    public string Message { get; set; } = "";

    public void OnGet(int? id)
    {
        if (id != null)
            Supplier = Database.Supplier(id.Value);

        Suppliers = Database.Suppliers();
        Message = TempData["Message"] as string ?? "";
    }

    public IActionResult OnPostSave()
    {
        Database.SaveSupplier(Supplier);
        TempData["Message"] = "Saved successfully.";
        return RedirectToPage();
    }

    public IActionResult OnPostDelete(int id)
    {
        Database.DeleteSupplier(id);
        TempData["Message"] = "Deleted successfully.";
        return RedirectToPage();
    }
}
