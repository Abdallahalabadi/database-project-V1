using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WarqERP.Models;

namespace WarqERP.Pages;

public class PurchaseOrdersModel : PageModel
{
    [BindProperty]
    public NewOrder Order { get; set; } = new();

    public List<Supplier> Suppliers { get; set; } = [];
    public List<Employee> Employees { get; set; } = [];
    public List<Product> Products { get; set; } = [];
    public List<PurchaseOrder> Orders { get; set; } = [];
    public string Message { get; set; } = "";

    public void OnGet()
    {
        LoadData();
        Message = TempData["Message"] as string ?? "";
    }

    public IActionResult OnPostSave()
    {
        Database.SaveOrder(Order);
        TempData["Message"] = "Order saved successfully.";
        return RedirectToPage();
    }

    public IActionResult OnPostDelete(int id)
    {
        Database.DeleteOrder(id);
        TempData["Message"] = "Order deleted successfully.";
        return RedirectToPage();
    }

    void LoadData()
    {
        Suppliers = Database.Suppliers();
        Employees = Database.Employees();
        Products = Database.Products();
        Orders = Database.Orders();
    }
}
