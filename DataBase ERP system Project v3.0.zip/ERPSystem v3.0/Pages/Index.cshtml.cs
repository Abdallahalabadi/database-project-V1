using Microsoft.AspNetCore.Mvc.RazorPages;
using WarqERP.Models;

namespace WarqERP.Pages;

public class IndexModel : PageModel
{
    public Dashboard Data { get; set; } = new();

    public void OnGet()
    {
        Data = Database.Dashboard();
    }
}
